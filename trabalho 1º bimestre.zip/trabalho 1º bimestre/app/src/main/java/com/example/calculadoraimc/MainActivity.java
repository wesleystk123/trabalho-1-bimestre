package com.example.calculadoraimc;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText ET_NOME, ET_EMAIL, ET_IDADE, ET_DISCIPLINA, ET_NOTA1, ET_NOTA2;
    private TextView TV_MENSAGEM, TV_RESULTADO;
    private Button BT_ENVIAR, BT_RESETAR;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializa os componentes
        ET_NOME = findViewById(R.id.ET_NOME);
        ET_EMAIL = findViewById(R.id.ET_EMAIL);
        ET_IDADE = findViewById(R.id.ET_IDADE);
        ET_DISCIPLINA = findViewById(R.id.ET_DISCIPLINA);
        ET_NOTA1 = findViewById(R.id.ET_NOTA1);
        ET_NOTA2 = findViewById(R.id.ET_NOTA2);
        TV_MENSAGEM = findViewById(R.id.TV_MENSAGEM);
        TV_RESULTADO = findViewById(R.id.TV_RESULTADO);
        BT_ENVIAR = findViewById(R.id.BT_ENVIAR);
        BT_RESETAR = findViewById(R.id.BT_RESETAR);

        // Ações dos botões
        BT_ENVIAR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validarEExibirDados();
            }
        });
        BT_RESETAR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resetarFormulario();
            }
        });
    }

    private void validarEExibirDados() {
        String nome = ET_NOME.getText().toString();
        String email = ET_EMAIL.getText().toString();
        String idadeStr = ET_IDADE.getText().toString();
        String disciplina = ET_DISCIPLINA.getText().toString();
        String nota1Str = ET_NOTA1.getText().toString();
        String nota2Str = ET_NOTA2.getText().toString();

        // Verifica campos obrigatórios
        boolean camposValidos = true;

        if (TextUtils.isEmpty(nome) || TextUtils.isEmpty(email) || TextUtils.isEmpty(idadeStr) || TextUtils.isEmpty(disciplina) || TextUtils.isEmpty(nota1Str) || TextUtils.isEmpty(nota2Str)) {
            TV_MENSAGEM.setText("Preencha todos os campos!");
            camposValidos = false;
        }

        if (camposValidos) {
            int idade = idadeStr.matches("\\d+") ? Integer.parseInt(idadeStr) : -1;
            float nota1 = nota1Str.matches("\\d+(\\.\\d+)?") ? Float.parseFloat(nota1Str) : -1;
            float nota2 = nota2Str.matches("\\d+(\\.\\d+)?") ? Float.parseFloat(nota2Str) : -1;

            if (idade > 0 && nota1 >= 0 && nota1 <= 10 && nota2 >= 0 && nota2 <= 10) {
                // Calcula a média e exibe o resultado
                float media = (nota1 + nota2) / 2;
                String resultado = String.format("Nome: %s\nEmail: %s\nIdade: %d\nDisciplina: %s\nMédia: %.2f\n%s",
                        nome, email, idade, disciplina, media, (media >= 6 ? "Aprovado" : "Reprovado"));
                TV_RESULTADO.setText(resultado);
                TV_MENSAGEM.setText("");
            } else {
                TV_MENSAGEM.setText("Idade ou notas inválidas.");
            }
        }
    }

    private void resetarFormulario() {
        ET_NOME.setText("");
        ET_EMAIL.setText("");
        ET_IDADE.setText("");
        ET_DISCIPLINA.setText("");
        ET_NOTA1.setText("");
        ET_NOTA2.setText("");
        TV_MENSAGEM.setText("");
        TV_RESULTADO.setText("");
        Toast.makeText(this, "Formulário resetado", Toast.LENGTH_SHORT).show();
    }
}
